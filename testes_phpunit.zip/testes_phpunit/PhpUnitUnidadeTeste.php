<?php

use PHPUnit\Framework\TestCase;
require_once("PhpUnitUnidade.php");

class PHPUnitUnidadeTeste extends TestCase{
    public function testcontarPar(){
        $numeros = [1,2,3,4,5,6,7,8,9,10];

        $phpUnitUnidade = new PhpUnitUnidade();
        $result = $phpUnitUnidade->contarPar($numeros);
        $this->assertGreaterThan(3, $result);
    }


    public function testresultbre(){
        $numero1 = 2;
        $numero2 = 2;
        $operação = "+";

        $phpUnitUnidade = new PhpUnitUnidade();
        $resultado = $phpUnitUnidade->resultbre($operação, $numero1, $numero2);
        $this->assertEquals(4, $resultado);
    
    }

    public function testverificastring(){
        $string = "cinco";

        $phpUnitUnidade = new PhpUnitUnidade();
        $qtde = $phpUnitUnidade->verificastring($string);
        $this->assertGreaterThan(5, $qtde);
    }

    public function testgerarmil(){

        $phpUnitUnidade = new PhpUnitUnidade();
        $list = $phpUnitUnidade->gerarmil();
        $this->assertGreaterThan(1000, $list);
    }

    public function testverifica_hash(){

        $password = 'Senai2022';
        // $hash_existente = "881cae19c0e9fc6456fae89462f5157fca0f3fa7d010841a0382f98de9144866";

        $phpUnitUnidade = new PhpUnitUnidade();
        $result = $phpUnitUnidade->verifica_hash($password);
        $this->assertTrue($result);
    }    
}
