<?php
    class PhpUnitUnidade{
        public function contarPar($numeros){
                
            $result = 0;
            foreach ($numeros as $numero) {
             if ($numero %2 == 0) {
                 $result++;
             }
            }
            return $result;
        }

        public function resultbre($operação, $numero1, $numero2) {
            $resultado = 0;
            switch ($operação) {
                case "+":
                    $resultado = $numero1 + $numero2;
                    break;
                case "-":
                    $resultado = $numero1 - $numero2;
                    break;
                case "*":
                    $resultado = $numero1 * $numero2;
                    break;
                case "/":
                    $resultado = $numero1 / $numero2;
                    break;  
            }
            return $resultado;
        }

        public function verificastring($string){
            $qtde = strlen($string);
            return $qtde;
        }

        public function gerarmil(){
            $list = [];
            for ($i=0; $i < 999; $i++) { 
                array_push($list, $i);
            }
            return $list;
        }

        public function verifica_hash($password){
            
            $sha = hash('sha256', $password);

            if($sha == '881cae19c0e9fc6456fae89462f5157fca0f3fa7d010841a0382f98de9144866'){
                $result = true;
            } else {
                $result = false;
            }
            return $result;
        }

    }        
?>

